package SistemaDeGestion;

public interface CSVSerializable {
    String toCSV();
    
}
