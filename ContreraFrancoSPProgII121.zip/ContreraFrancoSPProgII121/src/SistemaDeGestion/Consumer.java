package SistemaDeGestion;


public interface Consumer<T> {
    void accept(T t);
}